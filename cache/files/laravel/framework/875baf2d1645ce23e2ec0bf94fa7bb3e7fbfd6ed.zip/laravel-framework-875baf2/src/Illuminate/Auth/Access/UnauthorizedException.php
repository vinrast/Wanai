<?php

namespace Illuminate\Auth\Access;

use Exception;

class UnauthorizedException extends Exception
{
    //
}
