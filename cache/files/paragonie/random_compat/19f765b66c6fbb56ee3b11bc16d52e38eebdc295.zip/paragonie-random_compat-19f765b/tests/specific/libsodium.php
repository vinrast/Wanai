<?php
$ut_dir = dirname(dirname(__DIR__));
require_once $ut_dir.'/lib/byte_safe_strings.php';
require_once $ut_dir.'/lib/cast_to_int.php';
require_once $ut_dir.'/lib/error_polyfill.php';
require_once $ut_dir.'/lib/random_bytes_libsodium.php';
require_once $ut_dir.'/lib/random_int.php';